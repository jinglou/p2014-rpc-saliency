The saliency maps of our RPC method on the dataset ECSSD, if you use this result please cite:
Jing Lou, Mingwu Ren and Huan Wang, "Regional Principal Color Based Saliency Detection," PLoS ONE, vol. 9, no. 11, pp. e112475: 1-13, 2014. doi: 10.1371/journal.pone.0112475
Project webpage: http://www.loujing.com/rpc-saliency