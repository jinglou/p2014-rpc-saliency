If you use this code please cite:
Lou J, Ren M, Wang H (2014) Regional Principal Color Based Saliency Detection. PLoS ONE 9(11): e112475. doi:10.1371/journal.pone.0112475
Project webpage: http://www.loujing.com/rpc-saliency/
Date: Dec 02, 2014


Our algorithm can be run in a row by the command:
    > Demo

-Folders
    <images>		Input images
    <GloSalMaps>	Global saliency maps
    <RegSalMaps>	Regional saliency maps (our final retults)